# baidu-ife
百度IFE2016春季 我的代码

## 目前完成度：

+ [x] [task001_3 三栏式布局](http://xxthink.com/baidu-ife/task/task001/task001_3/index.html)
+ [x] [task001_4 定位和居中问题](http://xxthink.com/baidu-ife/task/task001/task001_4/index.html)
+ [x] [task001_6 模拟报纸](http://xxthink.com/baidu-ife/task/task001/task001_6/index.html)
+ [x] [task001_7 常见官网布局](http://xxthink.com/baidu-ife/task/task001/task001_7/index.html)
+ [x] [task001_8 栅格化布局](http://xxthink.com/baidu-ife/task/task001/task001_8/index.html)
+ [x] [task002_26 行星与飞船 一](http://xxthink.com/baidu-ife/task/task002/task002_26/index.html)
+ [x] [task002_27 行星与飞船 二](http://xxthink.com/baidu-ife/task/task002/task002_27/index.html)
+ [x] [task002_28 行星与飞船 三](http://xxthink.com/baidu-ife/task/task002/task002_28/index.html)
+ [x] [task002_33 听指令的小方块 一](http://xxthink.com/baidu-ife/task/task002/task002_33/index.html)
+ [x] [task002_34 听指令的小方块 二](http://xxthink.com/baidu-ife/task/task002/task002_34/index.html)
+ [x] [task002_35 听指令的小方块 三](http://xxthink.com/baidu-ife/task/task002/task002_35/index.html)
+ [x] [task003_37 UI组件 浮出层](http://xxthink.com/baidu-ife/task/task003/task003_37/index.html)
+ [x] [task003_43 拼图布局](http://xxthink.com/baidu-ife/task/task003/task003_43/index.html)
+ [x] [task003_44 瀑布布局](http://xxthink.com/baidu-ife/task/task003/task003_44/index.html)
